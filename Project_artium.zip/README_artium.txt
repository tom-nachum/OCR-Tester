Team Members:
Aviram Yitzhak, 312181506, Aviram.Yitzhak1@mail.huji.ac.il
Shahar Mor, 203713417, Shahar.Mor@mail.huji.ac.il
Tom Nahum, 316240985, tom.nahum@mail.huji.ac.il
Omer Salman, 208966549, omer.salman@mail.huji.ac.il

Details of PC:
Processor: Intel(R) Core(TM) i7-5600U @ 2.60GHz 2.59 GHz
RAM: 16.0 GB
OS: Windows 10